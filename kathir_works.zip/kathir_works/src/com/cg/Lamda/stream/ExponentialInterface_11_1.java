//11.1
package com.cg.Lamda.stream;

public interface ExponentialInterface_11_1 
{
	public abstract double exp(int x, int y);

}
