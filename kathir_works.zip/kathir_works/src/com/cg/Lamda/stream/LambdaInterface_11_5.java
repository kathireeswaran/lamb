//11.5
package com.cg.Lamda.stream;

public interface LambdaInterface_11_5 
{
	public abstract void fact(int n);
}
